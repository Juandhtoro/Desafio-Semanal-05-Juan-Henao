document.addEventListener('DOMContentLoaded', function () {
    const addButton = document.querySelectorAll('.button--add');
    const removeButton = document.querySelectorAll('.button--remove');
    const cartQuantity = document.querySelectorAll('.quantity');
    const cartModal = document.getElementById('cartModal');
    const cartSummary = document.getElementById('cartSummary');
    const closeButton = document.querySelector('.close');

    let quantities = new Array(cartQuantity.length).fill(0);
    let totalItems = 0;

    addButton.forEach((button, index) => {
        button.addEventListener('click', function (e) {
            // const button = e.target;
            // const itemTwo = button.closest('.card--product');
            // let itemImage = itemTwo.querySelector('.card__image').src;
            quantities[index]++;
            cartQuantity[index].innerText = quantities[index];
            updateCartCounter();
            // console.log(itemImage);

        });
    });


    removeButton.forEach((button, index) => {
        button.addEventListener('click', function () {
            if (quantities[index] > 0) {
                quantities[index]--;
                cartQuantity[index].innerText = quantities[index];
                updateCartCounter();
            }
        });
    });


    function updateCartCounter() {
        const totalCartItems = quantities.reduce((total, quantity) => total + quantity, 0);
        document.querySelector('.cart__quantity').innerText = totalCartItems.toString();
    }

    function showCart() {
        cartModal.style.display = 'block';
        cartSummary.innerHTML = '';
        cartQuantity.forEach((quantity, index) => {
            if (parseInt(quantity.innerText) > 0) {
                const itemName = quantity.parentElement.previousElementSibling.innerText;
                const itemPrice = parseFloat(quantity.parentElement.previousElementSibling.nextElementSibling.innerText.replace(',', '.'));
                const itemTotalPrice = itemPrice * totalItems;

                const cartItem = document.createElement('div');
                cartItem.innerHTML = `<p>${itemName} - Cantidad: ${quantity.innerText} - Precio total: ${itemTotalPrice.toFixed(2)}</p>`;
                cartSummary.appendChild(cartItem);
            }
        });
    }

    document.querySelector('.navbar__cart').addEventListener('click', showCart);

    closeButton.addEventListener('click', function () {
        cartModal.style.display = 'none';
    });

    window.addEventListener('click', function (event) {
        if (event.target === cartModal) {
            cartModal.style.display = 'none';
        }
    });
});