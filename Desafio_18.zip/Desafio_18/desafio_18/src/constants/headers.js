const HEADER_CONTENT_TYPE = { "Content-Type": "application/json" };

module.exports = {
    HEADER_CONTENT_TYPE,
};